Project Criteria met:

Should be all of them (to the best of our knowledge).

Additional comments / features:
One point that we may want to consider in the future is to add more
UNIQUE keys into our databases, because we have quite a bit of database
pollution when we do refreshes, to see if our website changes worked. 

We additionally implemented the page on Directors almost exactly the same
way as we did for Actors. Therefore, there are several pages (such as the
search) which also include Director information, which may change them
slightly from the exact results of the CS143s. However, if you disconsider
those, they should be the exact same. 

We did not end up doing any fancy things to the webpage to make it look
better, so there is a very simplistic user interface design.

Additionally, we tried to make the website as easy to interface for a user
as possible, by putting links to other websites that make sense from
each location. 
