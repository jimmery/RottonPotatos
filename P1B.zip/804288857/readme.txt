work was split by pair programming for the entire project.
since this project was so straightforward, all decisions were
made together and concurrently.
